# Ubuntu Grant Proposal App

This Streamlit app helps community organizations like Ubuntu Dance and Theatre Arts generate grant proposals, manage project data, and find relevant grant opportunities.

## 🚀 Features
- Generate a Word document proposal with logo, budget, objectives, and impact
- Automatically scrape and cache grant opportunities from key South African sites
- Use sample data or build custom input forms (editable)

## 🛠 Requirements
Install dependencies with:

```bash
pip install -r requirements.txt
```

## ▶️ Running the App
```bash
streamlit run app.py
```

## 🌍 Optional: Deploy to Streamlit Cloud
1. Push this repo to GitHub
2. Go to https://streamlit.io/cloud
3. Click "New app", connect your GitHub repo, and deploy!

---
Ubuntu Dance and Theatre Arts • Cape Town, South Africa
